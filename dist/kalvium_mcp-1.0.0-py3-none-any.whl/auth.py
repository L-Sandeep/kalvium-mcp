"""Authenticated browser lifecycle helpers for Kalvium automation."""

from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from playwright.sync_api import (
    BrowserContext,
    Error as PlaywrightError,
    Page,
    Playwright,
    sync_playwright,
)

PROJECT_DIRECTORY = Path(__file__).resolve().parent
PROFILE_DIRECTORY = PROJECT_DIRECTORY / "profiles" / "default"
LEGACY_PROFILE_DIRECTORY = PROJECT_DIRECTORY / "playwright-profile"


def ensure_profile_directory() -> Path:
    """Return the default profile directory, migrating the legacy one if needed."""
    PROFILE_DIRECTORY.parent.mkdir(parents=True, exist_ok=True)

    if PROFILE_DIRECTORY.exists():
        if not PROFILE_DIRECTORY.is_dir():
            raise NotADirectoryError(
                f"Default Playwright profile path is not a directory: {PROFILE_DIRECTORY}"
            )
        return PROFILE_DIRECTORY

    if LEGACY_PROFILE_DIRECTORY.exists():
        if not LEGACY_PROFILE_DIRECTORY.is_dir():
            raise NotADirectoryError(
                "Legacy Playwright profile path is not a directory: "
                f"{LEGACY_PROFILE_DIRECTORY}"
            )
        LEGACY_PROFILE_DIRECTORY.rename(PROFILE_DIRECTORY)
    else:
        PROFILE_DIRECTORY.mkdir()

    return PROFILE_DIRECTORY


@contextmanager
def open_browser() -> Iterator[tuple[BrowserContext, Page]]:
    """Open the existing authenticated Chrome profile and yield its context and page.

    The function never performs login or modifies authentication state.  Closing the
    context and Playwright instance on exit releases the profile lock cleanly.
    """
    profile_directory = ensure_profile_directory()

    playwright: Playwright = sync_playwright().start()
    context: BrowserContext | None = None
    try:
        try:
            context = playwright.chromium.launch_persistent_context(
                user_data_dir=str(profile_directory),
                channel="chrome",
                headless=False,
            )
        except PlaywrightError as exc:
            if "existing browser session" in str(exc):
                raise RuntimeError(
                    "The Playwright profile is already open. Close every Chrome "
                    f"window using {profile_directory} before starting the MCP server."
                ) from exc
            raise RuntimeError("Chrome could not be launched with the Playwright profile.") from exc
        page = context.pages[0] if context.pages else context.new_page()
        yield context, page
    finally:
        if context is not None:
            context.close()
        playwright.stop()
